-ici vous trouvez toutes les pages HTML
-la page principale du site est bien acceuil.htm 
-pour v�rifier l'identification il suffit de vous s'inscrire se d�connecter puis vous pouvez vous identifier 
-sinon il y'a une petite Base de donn�es dans le fichiez JSCConnex.js mise en commentaire au d�but du code ,
d�commentez le code et essayez de vous identifier avec les info de la data .

